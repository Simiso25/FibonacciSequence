/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fibonnaccisequence;
import java.util.Scanner;
/**
 *
 * @author Lenovo-User
 */
public class App {

    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        
	System.out.println("enter number of terms : ");
	int n =scanner.nextInt();
        
	int first=0,second=1,nextTerm;
        
	System.out.println("Fibonacci series is ");
	for(int A=0; A<n; A++)
	{
            if(A<=1)
            {
                nextTerm=A;
            }
            else
            {
                nextTerm=first + second;
                first=second;
                second=nextTerm;
            }
            
	System.out.println(nextTerm);
	}
    }
}
